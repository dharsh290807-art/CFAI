package com.examproctor.controller;

import com.examproctor.model.ExamSession;
import com.examproctor.service.ExamSessionService;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.logging.Logger;

/**
 * ProctorController
 * ──────────────────
 * Lightweight HTTP server exposing the Java session management API.
 * Listens on port 8080 and proxies AI analysis to the Python engine on 5000.
 *
 * Endpoints:
 *   POST /api/sessions/start      – Start exam session
 *   POST /api/sessions/end        – End exam session
 *   POST /api/sessions/frame      – Submit webcam frame for analysis
 *   GET  /api/sessions/{id}       – Get session report
 *   GET  /api/sessions            – List all sessions (admin)
 *   GET  /health                  – Health check
 */
public class ProctorController {

    private static final Logger LOG = Logger.getLogger(ProctorController.class.getName());
    private static final int PORT = 8080;

    private final ExamSessionService service = new ExamSessionService();

    public void start() throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);
        server.createContext("/health",        new HealthHandler());
        server.createContext("/api/sessions",  new SessionHandler());
        server.setExecutor(java.util.concurrent.Executors.newFixedThreadPool(10));
        server.start();
        LOG.info("Java Proctor Controller started on http://0.0.0.0:" + PORT);
    }

    // ─── Handlers ─────────────────────────────────────────────────────

    class HealthHandler implements HttpHandler {
        @Override public void handle(HttpExchange ex) throws IOException {
            respond(ex, 200, "{\"status\":\"ok\",\"service\":\"Java Session Manager\",\"version\":\"1.0.0\"}");
        }
    }

    class SessionHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            String method = ex.getRequestMethod();
            String path   = ex.getRequestURI().getPath();
            String body   = readBody(ex);

            try {
                if ("POST".equals(method) && path.endsWith("/start")) {
                    handleStart(ex, body);
                } else if ("POST".equals(method) && path.endsWith("/end")) {
                    handleEnd(ex, body);
                } else if ("POST".equals(method) && path.endsWith("/frame")) {
                    handleFrame(ex, body);
                } else if ("GET".equals(method) && path.matches(".*/sessions/[^/]+")) {
                    String id = path.substring(path.lastIndexOf('/') + 1);
                    respond(ex, 200, toJson(service.getSessionReport(id)));
                } else if ("GET".equals(method) && path.endsWith("/sessions")) {
                    respond(ex, 200, toJsonList(service.getAllSessionSummaries()));
                } else {
                    respond(ex, 404, "{\"error\":\"Not Found\"}");
                }
            } catch (NoSuchElementException e) {
                respond(ex, 404, "{\"error\":\"" + e.getMessage() + "\"}");
            } catch (Exception e) {
                LOG.severe("Handler error: " + e.getMessage());
                respond(ex, 500, "{\"error\":\"Internal server error\"}");
            }
        }

        private void handleStart(HttpExchange ex, String body) throws IOException {
            String studentId   = extractJson(body, "student_id");
            String examId      = extractJson(body, "exam_id");
            String studentName = extractJson(body, "student_name");
            ExamSession session = service.startSession(studentId, examId, studentName);
            respond(ex, 201, String.format(
                "{\"sessionId\":\"%s\",\"status\":\"ACTIVE\",\"message\":\"Session started\"}",
                session.getSessionId()
            ));
        }

        private void handleEnd(HttpExchange ex, String body) throws IOException {
            String sessionId = extractJson(body, "session_id");
            ExamSession session = service.endSession(sessionId);
            Map<String, Object> report = service.getSessionReport(sessionId);
            respond(ex, 200, toJson(report));
        }

        private void handleFrame(HttpExchange ex, String body) throws IOException {
            String sessionId = extractJson(body, "session_id");
            String frame     = extractJson(body, "frame");
            Map<String, Object> result = service.processFrame(sessionId, frame);
            respond(ex, 200, toJson(result));
        }
    }

    // ─── Utility ──────────────────────────────────────────────────────

    private void respond(HttpExchange ex, int code, String json) throws IOException {
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().add("Content-Type", "application/json");
        ex.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
        ex.sendResponseHeaders(code, bytes.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(bytes); }
    }

    private String readBody(HttpExchange ex) throws IOException {
        try (InputStream is = ex.getRequestBody()) {
            return new String(is.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    private String extractJson(String json, String key) {
        String pattern = "\"" + key + "\"";
        int idx = json.indexOf(pattern);
        if (idx < 0) return "";
        int colon = json.indexOf(':', idx);
        int q1    = json.indexOf('"', colon);
        int q2    = json.indexOf('"', q1 + 1);
        return (q1 >= 0 && q2 > q1) ? json.substring(q1 + 1, q2) : "";
    }

    private String toJson(Map<String, Object> map) {
        StringBuilder sb = new StringBuilder("{");
        boolean first = true;
        for (Map.Entry<String, Object> e : map.entrySet()) {
            if (!first) sb.append(',');
            sb.append('"').append(e.getKey()).append("\":");
            Object v = e.getValue();
            if (v instanceof String) sb.append('"').append(v).append('"');
            else sb.append(v);
            first = false;
        }
        return sb.append('}').toString();
    }

    private String toJsonList(List<Map<String, Object>> list) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) sb.append(',');
            sb.append(toJson(list.get(i)));
        }
        return sb.append(']').toString();
    }

    // ─── Entry Point ──────────────────────────────────────────────────

    public static void main(String[] args) throws IOException {
        new ProctorController().start();
    }
}
