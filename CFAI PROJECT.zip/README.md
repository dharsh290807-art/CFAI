# Intelligent Exam Proctoring Logic
### AI-Powered Online Examination Monitoring System

---

## Overview

A full-stack intelligent proctoring system combining:
- **Python** — Computer vision AI engine (Flask + OpenCV + MediaPipe)
- **Java** — Session management backend (HTTP server, domain models)
- **HTML/CSS/JS** — Real-time monitoring frontend (WebRTC webcam, live dashboard)

---

## Project Structure

```
exam_proctor/
├── python/
│   ├── proctor_engine.py      # Flask REST API + AI detection logic
│   └── requirements.txt       # Python dependencies
│
├── java/
│   ├── ExamSession.java        # Domain model: session lifecycle
│   ├── ViolationRecord.java    # Immutable violation event model
│   ├── ExamSessionService.java # Business logic, Python integration
│   └── ProctorController.java  # Lightweight HTTP server (port 8080)
│
└── web/
    └── index.html              # Complete frontend (zero build step)
```

---

## Detection Capabilities

| Violation Type   | Severity | Detection Method             |
|-----------------|----------|------------------------------|
| Face Absence     | HIGH     | MediaPipe FaceMesh (0 faces) |
| Multiple Faces   | CRITICAL | MediaPipe FaceMesh (>1 face) |
| Head Turn (Yaw)  | MEDIUM   | solvePnP head-pose estimation|
| Head Tilt (Pitch)| MEDIUM   | solvePnP pitch angle         |
| Mobile Device    | HIGH     | Contour shape heuristic      |

---

## Setup & Run

### 1. Python AI Engine (Port 5000)

```bash
cd python
pip install -r requirements.txt
python proctor_engine.py
```

**API Endpoints:**
- `GET  /health`            — Health check
- `POST /api/analyse`       — Analyse a webcam frame
- `GET  /api/report/<id>`   — Get session report

**Frame Payload:**
```json
{
  "student_id": "STU-001",
  "exam_id":    "CS-MID-2024",
  "frame":      "<base64-encoded-JPEG>"
}
```

---

### 2. Java Session Manager (Port 8080)

```bash
cd java
javac *.java
java com.examproctor.controller.ProctorController
```

**API Endpoints:**
- `GET  /health`                   — Health check
- `POST /api/sessions/start`       — Start exam session
- `POST /api/sessions/end`         — End exam session
- `POST /api/sessions/frame`       — Submit frame for analysis
- `GET  /api/sessions`             — List all sessions
- `GET  /api/sessions/{id}`        — Get session report

---

### 3. Frontend (No server needed)

Simply open in a browser:
```
web/index.html
```

Or serve with any static server:
```bash
cd web
python -m http.server 3000
# Open: http://localhost:3000
```

---

## Architecture

```
Browser (HTML/JS)
   │  [WebRTC capture → base64 frame every 500ms]
   ▼
Java REST API :8080
   │  ExamSession EMA trust smoothing
   │  ViolationRecord persistence
   ▼
Python AI Engine :5000
   │  MediaPipe FaceMesh (468 landmarks)
   │  OpenCV HaarCascade (face detection)
   │  Head Pose via solvePnP
   │  Mobile heuristic (contour aspect ratio)
   ▼
JSON violations + trust_score → back to browser
```

---

## Trust Score Algorithm

**Frame Trust Score:**  
`score = 100 − Σ(penalty per violation severity)`

| Severity | Penalty |
|----------|---------|
| LOW      | 2       |
| MEDIUM   | 8       |
| HIGH     | 18      |
| CRITICAL | 35      |

**Session Trust (Java EMA):**  
`session_trust = 0.90 × session_trust + 0.10 × frame_score`

**Status Thresholds:**
- `CLEAN`      ≥ 85
- `WARNING`    60–84
- `SUSPICIOUS` 30–59
- `CRITICAL`   < 30 → session auto-terminated

---

## Production Enhancements

- Replace mobile heuristic with **YOLOv8** object detection
- Add **JWT authentication** to Java API
- Connect **PostgreSQL/MySQL** via JPA to Java service
- Add **WebSocket** push for real-time admin notifications
- Deploy Python engine with **Gunicorn + Nginx**
- Package Java with **Spring Boot** for production-grade REST
