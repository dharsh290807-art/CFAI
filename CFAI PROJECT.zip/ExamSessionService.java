package com.examproctor.service;

import com.examproctor.model.ExamSession;
import com.examproctor.model.ExamSession.SessionStatus;
import com.examproctor.model.ViolationRecord;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * ExamSessionService
 * ──────────────────
 * Manages the lifecycle of exam sessions, communicates with the Python
 * AI engine to analyse webcam frames, processes violation events, and
 * provides reporting capabilities.
 *
 * Architecture:
 *   Browser  ──►  Java REST layer  ──►  Python /api/analyse
 *                      │
 *                      ▼
 *                   In-Memory Store (→ DB in production)
 */
public class ExamSessionService {

    private static final Logger LOG = Logger.getLogger(ExamSessionService.class.getName());

    private static final String PYTHON_ENGINE_URL = "http://localhost:5000/api/analyse";
    private static final int    CRITICAL_ALERT_THRESHOLD = 3; // violations before alert

    // In-memory store (replace with JPA repository in production)
    private final Map<String, ExamSession> sessions = new ConcurrentHashMap<>();
    private final HttpClient httpClient;

    public ExamSessionService() {
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(5))
                .build();
    }

    // ── Session Lifecycle ─────────────────────────────────────────────

    /**
     * Create and start a new exam session for a student.
     */
    public ExamSession startSession(String studentId, String examId, String studentName) {
        String sessionId = UUID.randomUUID().toString();
        ExamSession session = new ExamSession(sessionId, studentId, examId, studentName);
        sessions.put(sessionId, session);
        LOG.info("Session started: " + session);
        return session;
    }

    /**
     * Terminate a session (exam submitted / time expired).
     */
    public ExamSession endSession(String sessionId) {
        ExamSession session = getSession(sessionId);
        session.setStatus(SessionStatus.COMPLETED);
        session.setEndTime(LocalDateTime.now());
        LOG.info("Session ended: " + session);
        return session;
    }

    /**
     * Forcibly terminate a session due to critical violations.
     */
    public ExamSession terminateSession(String sessionId, String reason) {
        ExamSession session = getSession(sessionId);
        session.setStatus(SessionStatus.TERMINATED);
        session.setEndTime(LocalDateTime.now());
        LOG.warning("Session TERMINATED [" + reason + "]: " + session);
        return session;
    }

    // ── Frame Analysis Pipeline ───────────────────────────────────────

    /**
     * Forward a base64-encoded webcam frame to the Python engine,
     * parse the response, update session state, and return a summary.
     *
     * @param sessionId  Active session ID
     * @param b64Frame   Base64 JPEG/PNG of the webcam frame
     * @return           Map with trust score, status, and any violations
     */
    public Map<String, Object> processFrame(String sessionId, String b64Frame) {
        ExamSession session = getSession(sessionId);

        // Build JSON payload
        String payload = String.format(
                "{\"student_id\":\"%s\",\"exam_id\":\"%s\",\"frame\":\"%s\"}",
                session.getStudentId(), session.getExamId(),
                b64Frame.replace("\"", "\\\"")
        );

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("sessionId", sessionId);

        try {
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(PYTHON_ENGINE_URL))
                    .header("Content-Type", "application/json")
                    .timeout(Duration.ofSeconds(10))
                    .POST(HttpRequest.BodyPublishers.ofString(payload))
                    .build();

            HttpResponse<String> httpResp = httpClient.send(req,
                    HttpResponse.BodyHandlers.ofString());

            if (httpResp.statusCode() == 200) {
                response.putAll(parsePythonResponse(session, httpResp.body()));
            } else {
                response.put("error", "Engine returned HTTP " + httpResp.statusCode());
            }
        } catch (Exception e) {
            LOG.severe("Frame processing error: " + e.getMessage());
            response.put("error", e.getMessage());
        }

        return response;
    }

    // ── Internal Helpers ──────────────────────────────────────────────

    /**
     * Minimal JSON parser for the Python engine response.
     * Replace with Jackson/Gson in production.
     */
    @SuppressWarnings("unchecked")
    private Map<String, Object> parsePythonResponse(ExamSession session, String json) {
        Map<String, Object> result = new LinkedHashMap<>();

        double trustScore = extractDouble(json, "trust_score", 100.0);
        String status     = extractString(json, "status", "CLEAN");
        int    faceCount  = (int) extractDouble(json, "face_count", 0);
        int    frameIdx   = (int) extractDouble(json, "frame_index", 0);

        session.updateTrustScore(trustScore);

        // Parse violations array (simplified – use Jackson in prod)
        List<String> rawViolations = extractViolations(json);
        for (String vRaw : rawViolations) {
            String vType     = extractString(vRaw, "type",      "UNKNOWN");
            String vSeverity = extractString(vRaw, "severity",  "LOW");
            String vMessage  = extractString(vRaw, "message",   "");
            double vConf     = extractDouble(vRaw, "confidence", 0.5);

            ViolationRecord vr = ViolationRecord.fromPythonPayload(
                    session.getSessionId(), vType, vSeverity, vMessage, vConf, frameIdx);
            session.addViolation(vr);

            LOG.warning("VIOLATION: " + vr);
        }

        // Auto-terminate if trust score is critically low
        if (session.isCritical() && session.getStatus() == SessionStatus.ACTIVE) {
            terminateSession(session.getSessionId(), "Trust score below threshold");
            status = "TERMINATED";
        }

        result.put("trustScore",    session.getTrustScore());
        result.put("status",        status);
        result.put("faceCount",     faceCount);
        result.put("frameIndex",    frameIdx);
        result.put("totalViolations", session.getTotalViolations());
        result.put("violations",    rawViolations);

        return result;
    }

    private ExamSession getSession(String sessionId) {
        ExamSession session = sessions.get(sessionId);
        if (session == null) throw new NoSuchElementException("Session not found: " + sessionId);
        return session;
    }

    // ── Minimal JSON helpers (no external deps) ───────────────────────

    private double extractDouble(String json, String key, double def) {
        String pattern = "\"" + key + "\"";
        int idx = json.indexOf(pattern);
        if (idx < 0) return def;
        int colon = json.indexOf(':', idx);
        if (colon < 0) return def;
        int start = colon + 1;
        while (start < json.length() && Character.isWhitespace(json.charAt(start))) start++;
        int end = start;
        while (end < json.length() && (Character.isDigit(json.charAt(end)) ||
               json.charAt(end) == '.' || json.charAt(end) == '-')) end++;
        try   { return Double.parseDouble(json.substring(start, end)); }
        catch (NumberFormatException e) { return def; }
    }

    private String extractString(String json, String key, String def) {
        String pattern = "\"" + key + "\"";
        int idx = json.indexOf(pattern);
        if (idx < 0) return def;
        int colon = json.indexOf(':', idx);
        if (colon < 0) return def;
        int q1 = json.indexOf('"', colon);
        if (q1 < 0) return def;
        int q2 = json.indexOf('"', q1 + 1);
        if (q2 < 0) return def;
        return json.substring(q1 + 1, q2);
    }

    private List<String> extractViolations(String json) {
        List<String> list = new ArrayList<>();
        int arrStart = json.indexOf("\"violations\"");
        if (arrStart < 0) return list;
        int bracketOpen = json.indexOf('[', arrStart);
        if (bracketOpen < 0) return list;
        int bracketClose = json.indexOf(']', bracketOpen);
        if (bracketClose < 0) return list;
        String arr = json.substring(bracketOpen + 1, bracketClose).trim();
        if (arr.isEmpty()) return list;

        // Split on top-level object boundaries
        int depth = 0, start = 0;
        for (int i = 0; i < arr.length(); i++) {
            char c = arr.charAt(i);
            if (c == '{') { if (depth == 0) start = i; depth++; }
            else if (c == '}') { depth--; if (depth == 0) list.add(arr.substring(start, i + 1)); }
        }
        return list;
    }

    // ── Reporting ─────────────────────────────────────────────────────

    public Map<String, Object> getSessionReport(String sessionId) {
        ExamSession session = getSession(sessionId);
        Map<String, Object> report = new LinkedHashMap<>();
        report.put("sessionId",           session.getSessionId());
        report.put("studentId",           session.getStudentId());
        report.put("studentName",         session.getStudentName());
        report.put("examId",              session.getExamId());
        report.put("startTime",           session.getStartTime().toString());
        report.put("endTime",             session.getEndTime() != null ? session.getEndTime().toString() : "ongoing");
        report.put("status",              session.getStatus().name());
        report.put("finalTrustScore",     session.getTrustScore());
        report.put("totalFrames",         session.getTotalFramesAnalysed());
        report.put("totalViolations",     session.getTotalViolations());
        return report;
    }

    public List<Map<String, Object>> getAllSessionSummaries() {
        List<Map<String, Object>> summaries = new ArrayList<>();
        for (ExamSession s : sessions.values()) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("sessionId",   s.getSessionId());
            m.put("studentName", s.getStudentName());
            m.put("examId",      s.getExamId());
            m.put("trustScore",  s.getTrustScore());
            m.put("status",      s.getStatus().name());
            m.put("violations",  s.getTotalViolations());
            summaries.add(m);
        }
        return summaries;
    }
}
