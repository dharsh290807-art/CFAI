package com.examproctor.model;

import java.time.LocalDateTime;

/**
 * Immutable record of a single proctoring violation event.
 * Serialised to JSON and persisted in the violations table.
 */
public class ViolationRecord {

    public enum ViolationType {
        NO_FACE, MULTIPLE_FACES, HEAD_TURN, MOBILE_DETECTED, UNKNOWN
    }

    public enum Severity {
        LOW, MEDIUM, HIGH, CRITICAL
    }

    private final String        id;
    private final String        sessionId;
    private final ViolationType type;
    private final Severity      severity;
    private final String        message;
    private final double        confidence;
    private final LocalDateTime timestamp;
    private final int           frameIndex;

    public ViolationRecord(String id, String sessionId, ViolationType type,
                           Severity severity, String message,
                           double confidence, int frameIndex) {
        this.id         = id;
        this.sessionId  = sessionId;
        this.type       = type;
        this.severity   = severity;
        this.message    = message;
        this.confidence = confidence;
        this.timestamp  = LocalDateTime.now();
        this.frameIndex = frameIndex;
    }

    // ── factory ───────────────────────────────

    /**
     * Parse a raw violation map returned by the Python AI engine
     * and construct a ViolationRecord.
     */
    public static ViolationRecord fromPythonPayload(String sessionId,
                                                    String typeStr,
                                                    String severityStr,
                                                    String message,
                                                    double confidence,
                                                    int frameIndex) {
        ViolationType vt;
        try   { vt = ViolationType.valueOf(typeStr.toUpperCase()); }
        catch (IllegalArgumentException e) { vt = ViolationType.UNKNOWN; }

        Severity sv;
        try   { sv = Severity.valueOf(severityStr.toUpperCase()); }
        catch (IllegalArgumentException e) { sv = Severity.LOW; }

        String id = sessionId + "_" + frameIndex + "_" + typeStr;
        return new ViolationRecord(id, sessionId, vt, sv, message, confidence, frameIndex);
    }

    // ── getters ───────────────────────────────

    public String        getId()         { return id; }
    public String        getSessionId()  { return sessionId; }
    public ViolationType getType()       { return type; }
    public Severity      getSeverity()   { return severity; }
    public String        getMessage()    { return message; }
    public double        getConfidence() { return confidence; }
    public LocalDateTime getTimestamp()  { return timestamp; }
    public int           getFrameIndex() { return frameIndex; }

    @Override
    public String toString() {
        return String.format("Violation{%s | %s | %s | frame=%d | conf=%.2f}",
                type, severity, message, frameIndex, confidence);
    }
}
