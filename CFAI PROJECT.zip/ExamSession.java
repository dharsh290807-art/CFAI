package com.examproctor.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Domain model representing an active exam session for a student.
 * Stored and managed by ExamSessionService and persisted via SessionRepository.
 */
public class ExamSession {

    public enum SessionStatus {
        PENDING, ACTIVE, PAUSED, COMPLETED, TERMINATED
    }

    private String sessionId;
    private String studentId;
    private String examId;
    private String studentName;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private SessionStatus status;
    private double trustScore;          // running average (0 – 100)
    private int totalFramesAnalysed;
    private int totalViolations;
    private List<ViolationRecord> violations;

    // ── constructors ──────────────────────────

    public ExamSession() {
        this.violations = new ArrayList<>();
        this.trustScore = 100.0;
    }

    public ExamSession(String sessionId, String studentId, String examId, String studentName) {
        this();
        this.sessionId   = sessionId;
        this.studentId   = studentId;
        this.examId      = examId;
        this.studentName = studentName;
        this.startTime   = LocalDateTime.now();
        this.status      = SessionStatus.ACTIVE;
    }

    // ── business logic ────────────────────────

    /**
     * Update the running trust score with the latest frame score.
     * Uses exponential moving average (α = 0.1) to smooth fluctuations.
     */
    public void updateTrustScore(double frameScore) {
        double alpha = 0.10;
        this.trustScore = (1 - alpha) * this.trustScore + alpha * frameScore;
        this.totalFramesAnalysed++;
    }

    public void addViolation(ViolationRecord v) {
        this.violations.add(v);
        this.totalViolations++;
    }

    public boolean isCritical() {
        return this.trustScore < 30.0;
    }

    // ── getters / setters ─────────────────────

    public String getSessionId()         { return sessionId; }
    public void   setSessionId(String v) { sessionId = v; }

    public String getStudentId()         { return studentId; }
    public void   setStudentId(String v) { studentId = v; }

    public String getExamId()            { return examId; }
    public void   setExamId(String v)    { examId = v; }

    public String getStudentName()            { return studentName; }
    public void   setStudentName(String v)    { studentName = v; }

    public LocalDateTime getStartTime()       { return startTime; }
    public void          setStartTime(LocalDateTime v) { startTime = v; }

    public LocalDateTime getEndTime()         { return endTime; }
    public void          setEndTime(LocalDateTime v)   { endTime = v; }

    public SessionStatus getStatus()          { return status; }
    public void          setStatus(SessionStatus v)    { status = v; }

    public double getTrustScore()        { return Math.round(trustScore * 10.0) / 10.0; }
    public int    getTotalFramesAnalysed()  { return totalFramesAnalysed; }
    public int    getTotalViolations()      { return totalViolations; }

    public List<ViolationRecord> getViolations() { return violations; }

    @Override
    public String toString() {
        return String.format("ExamSession{id='%s', student='%s', trust=%.1f, status=%s}",
                sessionId, studentName, trustScore, status);
    }
}
