"""
Intelligent Exam Proctoring Engine
====================================
AI-powered real-time exam monitoring using OpenCV, MediaPipe, and Flask.
Detects: multiple faces, absence, head movements, mobile phone usage.
"""

import cv2
import numpy as np
import mediapipe as mp
import json
import time
import base64
import logging
from datetime import datetime
from flask import Flask, request, jsonify
from flask_cors import CORS
from dataclasses import dataclass, asdict
from typing import Optional
import threading

# ─────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# ─────────────────────────────────────────────
# Data Models
# ─────────────────────────────────────────────
@dataclass
class ViolationEvent:
    type: str           # "NO_FACE" | "MULTIPLE_FACES" | "HEAD_TURN" | "MOBILE_DETECTED"
    severity: str       # "LOW" | "MEDIUM" | "HIGH" | "CRITICAL"
    message: str
    timestamp: str
    confidence: float   # 0.0 – 1.0
    frame_index: int

@dataclass
class ProctoringResult:
    student_id: str
    exam_id: str
    timestamp: str
    face_count: int
    head_pose: dict
    violations: list
    trust_score: float
    frame_index: int
    status: str         # "CLEAN" | "WARNING" | "SUSPICIOUS" | "CRITICAL"


# ─────────────────────────────────────────────
# AI Proctoring Core
# ─────────────────────────────────────────────
class ProctoringEngine:
    """
    Core AI engine for exam proctoring.
    Uses MediaPipe Face Mesh for head-pose estimation and
    OpenCV's Haar cascades for face + mobile detection.
    """

    # Head-pose thresholds (degrees)
    YAW_THRESHOLD   = 30.0   # left/right turn
    PITCH_THRESHOLD = 25.0   # up/down tilt

    # Consecutive suspicious-frame threshold before raising a violation
    CONSEC_FRAMES_THRESHOLD = 5

    def __init__(self):
        # MediaPipe Face Mesh
        self.mp_face_mesh = mp.solutions.face_mesh
        self.face_mesh = self.mp_face_mesh.FaceMesh(
            max_num_faces=5,
            refine_landmarks=True,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5,
        )

        # OpenCV face detector (Haar cascade – fallback)
        self.face_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        )

        # Simple mobile-phone proxy: large rectangular object + dark screen heuristic
        # In production, replace with a YOLOv8 model.
        self.mobile_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + "haarcascade_upperbody.xml"
        )

        # 3D model points for head-pose (generic face model)
        self.model_points = np.array([
            (0.0,    0.0,    0.0),    # Nose tip
            (0.0,   -330.0, -65.0),   # Chin
            (-225.0, 170.0, -135.0),  # Left eye corner
            (225.0,  170.0, -135.0),  # Right eye corner
            (-150.0,-150.0, -125.0),  # Left mouth corner
            (150.0, -150.0, -125.0),  # Right mouth corner
        ], dtype=np.float64)

        self.frame_index   = 0
        self.session_store = {}   # student_id -> session state
        logger.info("ProctoringEngine initialised.")

    # ── helpers ──────────────────────────────

    def _decode_frame(self, b64_data: str) -> Optional[np.ndarray]:
        """Decode a base64-encoded JPEG/PNG frame."""
        try:
            img_bytes = base64.b64decode(b64_data)
            arr = np.frombuffer(img_bytes, dtype=np.uint8)
            frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
            return frame
        except Exception as exc:
            logger.error(f"Frame decode error: {exc}")
            return None

    def _get_head_pose(self, landmarks, frame_w: int, frame_h: int) -> dict:
        """Estimate yaw / pitch / roll from face-mesh landmarks."""
        # Key landmark indices (MediaPipe 468-point mesh)
        idx = [1, 152, 263, 33, 287, 57]
        image_points = np.array([
            (landmarks[i].x * frame_w, landmarks[i].y * frame_h)
            for i in idx
        ], dtype=np.float64)

        focal_length = frame_w
        cam_matrix = np.array([
            [focal_length, 0,            frame_w / 2],
            [0,            focal_length, frame_h / 2],
            [0,            0,            1          ],
        ], dtype=np.float64)
        dist_coeffs = np.zeros((4, 1))

        success, rvec, tvec = cv2.solvePnP(
            self.model_points, image_points, cam_matrix, dist_coeffs,
            flags=cv2.SOLVEPNP_ITERATIVE,
        )
        if not success:
            return {"yaw": 0.0, "pitch": 0.0, "roll": 0.0}

        rmat, _ = cv2.Rodrigues(rvec)
        angles, *_ = cv2.RQDecomp3x3(rmat)
        return {
            "yaw":   round(float(angles[1]), 2),
            "pitch": round(float(angles[0]), 2),
            "roll":  round(float(angles[2]), 2),
        }

    def _detect_mobile(self, frame: np.ndarray) -> bool:
        """
        Heuristic mobile-phone detector.
        Looks for a dark rectangular region with high aspect ratio.
        Replace with YOLOv8 for production accuracy.
        """
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        _, thresh = cv2.threshold(blurred, 40, 255, cv2.THRESH_BINARY_INV)

        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for cnt in contours:
            x, y, w, h = cv2.boundingRect(cnt)
            area = w * h
            aspect = h / w if w > 0 else 0
            # Mobile-like: portrait rectangle, reasonable area
            if 1.4 < aspect < 2.5 and 3000 < area < 40000:
                return True
        return False

    # ── main analysis ─────────────────────────

    def analyse_frame(self, b64_frame: str, student_id: str, exam_id: str) -> ProctoringResult:
        self.frame_index += 1
        ts = datetime.utcnow().isoformat() + "Z"
        violations: list[ViolationEvent] = []

        frame = self._decode_frame(b64_frame)
        if frame is None:
            return ProctoringResult(
                student_id=student_id, exam_id=exam_id, timestamp=ts,
                face_count=0, head_pose={}, violations=[], trust_score=0.0,
                frame_index=self.frame_index, status="CRITICAL",
            )

        h, w = frame.shape[:2]
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self.face_mesh.process(rgb)

        face_count = len(results.multi_face_landmarks) if results.multi_face_landmarks else 0
        head_pose  = {}

        # ── violation checks ──────────────────

        # 1. No face
        if face_count == 0:
            violations.append(ViolationEvent(
                type="NO_FACE", severity="HIGH",
                message="Candidate not visible in frame.",
                timestamp=ts, confidence=0.95, frame_index=self.frame_index,
            ))

        # 2. Multiple faces
        elif face_count > 1:
            violations.append(ViolationEvent(
                type="MULTIPLE_FACES", severity="CRITICAL",
                message=f"{face_count} faces detected – possible impersonation.",
                timestamp=ts, confidence=min(0.7 + face_count * 0.1, 1.0),
                frame_index=self.frame_index,
            ))

        # 3. Head pose (first face only)
        if face_count >= 1:
            lm = results.multi_face_landmarks[0].landmark
            head_pose = self._get_head_pose(lm, w, h)

            if abs(head_pose["yaw"]) > self.YAW_THRESHOLD:
                direction = "left" if head_pose["yaw"] < 0 else "right"
                violations.append(ViolationEvent(
                    type="HEAD_TURN", severity="MEDIUM",
                    message=f"Head turned {direction} ({head_pose['yaw']:.1f}°).",
                    timestamp=ts,
                    confidence=min(abs(head_pose["yaw"]) / 90.0, 1.0),
                    frame_index=self.frame_index,
                ))

            if head_pose["pitch"] < -self.PITCH_THRESHOLD:
                violations.append(ViolationEvent(
                    type="HEAD_TURN", severity="MEDIUM",
                    message=f"Head tilted down ({head_pose['pitch']:.1f}°) – possible reading from notes.",
                    timestamp=ts,
                    confidence=min(abs(head_pose["pitch"]) / 90.0, 1.0),
                    frame_index=self.frame_index,
                ))

        # 4. Mobile phone
        if self._detect_mobile(frame):
            violations.append(ViolationEvent(
                type="MOBILE_DETECTED", severity="HIGH",
                message="Possible mobile device detected in frame.",
                timestamp=ts, confidence=0.75, frame_index=self.frame_index,
            ))

        # ── trust score ──────────────────────
        penalty = sum({
            "LOW": 2, "MEDIUM": 8, "HIGH": 18, "CRITICAL": 35
        }.get(v.severity, 0) for v in violations)
        trust_score = max(0.0, round(100.0 - penalty, 1))

        if trust_score >= 85:
            status = "CLEAN"
        elif trust_score >= 60:
            status = "WARNING"
        elif trust_score >= 30:
            status = "SUSPICIOUS"
        else:
            status = "CRITICAL"

        return ProctoringResult(
            student_id=student_id, exam_id=exam_id, timestamp=ts,
            face_count=face_count, head_pose=head_pose,
            violations=[asdict(v) for v in violations],
            trust_score=trust_score, frame_index=self.frame_index, status=status,
        )


# ─────────────────────────────────────────────
# Flask REST API
# ─────────────────────────────────────────────
engine = ProctoringEngine()

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "service": "Proctor Engine", "version": "1.0.0"})


@app.route("/api/analyse", methods=["POST"])
def analyse():
    """
    POST /api/analyse
    Body: { "student_id": str, "exam_id": str, "frame": "<base64-image>" }
    Returns: ProctoringResult as JSON
    """
    data = request.get_json(force=True)
    required = {"student_id", "exam_id", "frame"}
    if not required.issubset(data):
        return jsonify({"error": f"Missing fields: {required - data.keys()}"}), 400

    result = engine.analyse_frame(
        b64_frame  = data["frame"],
        student_id = data["student_id"],
        exam_id    = data["exam_id"],
    )
    return jsonify(asdict(result))


@app.route("/api/report/<exam_id>", methods=["GET"])
def report(exam_id: str):
    """Stub: return aggregated session report (extend with DB integration)."""
    return jsonify({
        "exam_id": exam_id,
        "message": "Connect to database (via Java service) for full report.",
        "total_frames_analysed": engine.frame_index,
    })


if __name__ == "__main__":
    logger.info("Starting Proctor Engine on http://0.0.0.0:5000")
    app.run(host="0.0.0.0", port=5000, debug=False, threaded=True)
